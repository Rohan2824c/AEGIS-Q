# AegisQ Design System — Japanese Blue Minimal Glass

## Direction
A calm, premium cyber-risk interface using traditional Japanese blue families as the visual foundation. The interface is intentionally less neon and less “hacker” oriented, while retaining a technical/futuristic feel.

## Core colors
- Kon-iro: `#233B6C` family — deep navy foundation
- Ai-iro: `#165E83` — primary indigo accent
- Hanada: `#3C6E8F` — secondary blue
- Mizu-iro: `#AFDFE4` family — pale blue highlights
- Warm white: used for readable business data and hierarchy
- Muted amber / sage: used only for warning and improvement states

Japanese traditional blue references vary by source and historical usage; HEX values are treated as digital approximations rather than immutable historical pigment values.

## Data presentation
Financial figures are compacted into Indian units (₹K / ₹L / ₹Cr) to suit SMB and mid-market decision making. ROSI is displayed as a multiple to make the business meaning clearer.
