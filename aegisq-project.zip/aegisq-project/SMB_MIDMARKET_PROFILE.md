# AegisQ — SMB / Mid-Market Display Profile

AegisQ is presented as a practical cyber-risk decision tool for small and mid-sized companies.

## Display conventions
- Currency is shown in compact Indian units: ₹K, ₹L, ₹Cr.
- Security budgets are intended to feel operationally realistic: roughly ₹5L–₹50L for the demo scenarios.
- ROSI is shown as a multiplier (for example, 1.9×) rather than a large percentage. This means net financial benefit per ₹1 invested.
- Detailed numbers remain available through the optimizer/scenario context; the dashboard favors quick business-readable summaries.

## Japanese blue palette
The final UI uses a restrained traditional-Japanese-blue-inspired palette: Kon-iro / deep navy, Ai-iro / indigo blue, Hanada / muted indigo, and Mizu-iro / pale water blue, with warm neutral typography. Digital HEX values are approximations of traditional color references.

## Product language
Prefer labels such as:
- Annual financial exposure
- Estimated risk avoided
- Security budget
- Net value per ₹1 invested
- Asset Number / Asset Name / Department

Avoid overly enterprise-heavy language where a simpler phrase communicates the same decision.
